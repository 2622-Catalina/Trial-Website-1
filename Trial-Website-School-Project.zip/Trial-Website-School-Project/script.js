const obj = { a: 13, b: 42, c: 211 };
for (i in obj) console.log(i + ': ' + obj[i]);
